﻿namespace WorldOfNinja.Interfaces
{
    public interface IUsable : IGameObject
    {
    }
}
