﻿namespace WorldOfNinja.Interfaces
{
    public interface IEnergyExpandable : IUsable
    {
        int UpgradeTotalEnergy { get; }
    }
}
