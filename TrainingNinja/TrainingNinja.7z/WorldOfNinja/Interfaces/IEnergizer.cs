﻿namespace WorldOfNinja.Interfaces
{
    public interface IEnergizer : IUsable
    {
        int HealingPoints { get; }
    }
}
