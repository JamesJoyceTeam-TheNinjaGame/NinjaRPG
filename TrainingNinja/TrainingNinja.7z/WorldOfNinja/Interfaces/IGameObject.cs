﻿namespace WorldOfNinja.Interfaces
{
    public interface IGameObject
    {
        string Name { get; }
    }
}
