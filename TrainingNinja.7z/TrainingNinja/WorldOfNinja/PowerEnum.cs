﻿namespace WorldOfNinja
{
    public enum PowerEnum
    {
        ForcePower,
        MentalPower
    }
}
